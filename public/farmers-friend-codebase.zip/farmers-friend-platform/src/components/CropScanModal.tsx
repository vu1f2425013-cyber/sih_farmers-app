import React, { useState } from 'react';
import {
  X,
  Upload,
  Camera,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  ShieldCheck,
  ChevronRight,
  RefreshCw,
  FileCheck,
  Calendar,
  Send,
} from 'lucide-react';
import { Field, AIAnalysisResult, Language } from '../types';
import { SAMPLE_SCAN_PRESETS } from '../data/seedData';
import { api } from '../services/api';
import { ExplainableAIPanel } from './ExplainableAIPanel';
import { TRANSLATIONS } from '../i18n/translations';

interface CropScanModalProps {
  isOpen: boolean;
  onClose: () => void;
  fields: Field[];
  selectedFieldId?: string;
  language: Language;
  onCaseCreated: () => void;
}

export const CropScanModal: React.FC<CropScanModalProps> = ({
  isOpen,
  onClose,
  fields,
  selectedFieldId,
  language,
  onCaseCreated,
}) => {
  const t = TRANSLATIONS[language];
  const [step, setStep] = useState<'input' | 'analyzing' | 'result'>('input');
  const [selectedField, setSelectedField] = useState<string>(selectedFieldId || fields[0]?.id || 'field-1');
  const [crop, setCrop] = useState<string>(fields[0]?.crop || 'Soybean');
  const [variety, setVariety] = useState<string>(fields[0]?.variety || 'JS 20-29');
  const [growthStage, setGrowthStage] = useState<string>(fields[0]?.growthStage || 'R3 Pod Development');
  const [farmerNotes, setFarmerNotes] = useState<string>('');
  const [imagePreview, setImagePreview] = useState<string>(SAMPLE_SCAN_PRESETS[0].imageUrl);
  const [analyzingProgress, setAnalyzingProgress] = useState<string>('Initializing multimodal context...');
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);
  const [submittingCase, setSubmittingCase] = useState(false);
  const [caseSavedMessage, setCaseSavedMessage] = useState(false);

  if (!isOpen) return null;

  const currentFieldObj = fields.find((f) => f.id === selectedField) || fields[0];

  const handleFieldChange = (fId: string) => {
    setSelectedField(fId);
    const f = fields.find((item) => item.id === fId);
    if (f) {
      setCrop(f.crop);
      setVariety(f.variety);
      setGrowthStage(f.growthStage);
    }
  };

  const handleApplyPreset = (preset: typeof SAMPLE_SCAN_PRESETS[0]) => {
    setImagePreview(preset.imageUrl);
    setCrop(preset.crop);
    setVariety(preset.variety);
    setGrowthStage(preset.growthStage);
    setFarmerNotes(preset.description);
    if (preset.fieldId && fields.some((f) => f.id === preset.fieldId)) {
      setSelectedField(preset.fieldId);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const runAnalysis = async () => {
    setStep('analyzing');
    setCaseSavedMessage(false);
    setAnalyzingProgress('Reading leaf foliar patterns & lesions...');

    try {
      setTimeout(() => setAnalyzingProgress('Evaluating weather microclimate & humidity history...'), 600);
      setTimeout(() => setAnalyzingProgress('Cross-referencing persistent Field Health Memory...'), 1200);

      const result = await api.analyzeCropImage({
        imageBase64: imagePreview,
        crop,
        variety,
        growthStage,
        fieldId: selectedField,
        farmerNotes,
      });

      setAnalysisResult(result);
      setStep('result');
    } catch (err) {
      console.error('Analysis error:', err);
      setStep('input');
      alert('Analysis temporarily unavailable. Please verify connection and try again.');
    }
  };

  const handleSaveAsCase = async () => {
    if (!analysisResult) return;
    setSubmittingCase(true);
    try {
      await api.createCase({
        fieldId: selectedField,
        image: imagePreview,
        farmerNotes,
        aiAnalysis: analysisResult,
      });
      setCaseSavedMessage(true);
      onCaseCreated();
      setTimeout(() => {
        onClose();
        setStep('input');
      }, 1500);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingCase(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-stone-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-emerald-800 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-emerald-200" />
            </div>
            <div>
              <h3 className="font-bold text-base tracking-tight">
                AI Crop Health Diagnostic Scan
              </h3>
              <p className="text-xs text-emerald-200">
                Multimodal Image Reasoning + Weather + Growth Stage + Health Memory
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="p-1.5 rounded-lg hover:bg-white/20 text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-stone-800 flex-1">
          {step === 'input' && (
            <>
              {/* Step 1: Choose Leaf Image or Quick SIH Judge Presets */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                  1. Crop Image (Upload File or Use SIH Judge Test Presets)
                </label>

                {/* SIH Judge Presets */}
                <div className="mb-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {SAMPLE_SCAN_PRESETS.map((pr) => (
                    <button
                      key={pr.id}
                      type="button"
                      onClick={() => handleApplyPreset(pr)}
                      className={`p-2 rounded-xl text-left border transition-all text-xs flex flex-col justify-between ${
                        imagePreview === pr.imageUrl
                          ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-600/20'
                          : 'border-stone-200 hover:border-emerald-300 bg-stone-50'
                      }`}
                    >
                      <div className="w-full h-14 rounded-lg overflow-hidden mb-1.5 bg-stone-200">
                        <img
                          src={pr.imageUrl}
                          alt={pr.crop}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <span className="font-bold text-stone-900 line-clamp-1">{pr.crop}</span>
                      <span className="text-[10px] text-stone-500 line-clamp-1">{pr.mockIssue}</span>
                    </button>
                  ))}
                </div>

                {/* Upload custom box */}
                <div className="flex flex-col sm:flex-row items-center gap-4 p-4 border-2 border-dashed border-stone-200 rounded-xl bg-stone-50/70 hover:bg-stone-50 transition-colors">
                  {imagePreview && (
                    <div className="w-24 h-24 rounded-lg overflow-hidden border border-stone-200 shrink-0 shadow-xs">
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                  <div className="flex-1 text-center sm:text-left">
                    <p className="text-xs font-semibold text-stone-800">
                      Upload from phone camera or device
                    </p>
                    <p className="text-[11px] text-stone-500 mb-2">
                      Clear view of affected leaves, spots, lesions, or pest damage
                    </p>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-stone-300 hover:bg-stone-50 rounded-lg text-xs font-medium cursor-pointer shadow-2xs">
                      <Upload className="w-3.5 h-3.5 text-stone-600" />
                      <span>Choose Image File</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>
              </div>

              {/* Step 2: Contextual Field Information */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2">
                  2. Agronomic Field Context (Crucial for Contextual Reasoning)
                </label>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-stone-600 font-medium mb-1">Target Field</label>
                    <select
                      value={selectedField}
                      onChange={(e) => handleFieldChange(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    >
                      {fields.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name} ({f.crop} - {f.areaAcres} ac)
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-stone-600 font-medium mb-1">Crop & Variety</label>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={crop}
                        onChange={(e) => setCrop(e.target.value)}
                        placeholder="Crop"
                        className="px-3 py-2 rounded-lg border border-stone-300 bg-white"
                      />
                      <input
                        type="text"
                        value={variety}
                        onChange={(e) => setVariety(e.target.value)}
                        placeholder="Variety"
                        className="px-3 py-2 rounded-lg border border-stone-300 bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-stone-600 font-medium mb-1">Growth Stage</label>
                    <input
                      type="text"
                      value={growthStage}
                      onChange={(e) => setGrowthStage(e.target.value)}
                      placeholder="e.g. Flowering, R3 Pod Development"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-stone-600 font-medium mb-1">
                      Current Microclimate Signals (Auto-populated)
                    </label>
                    <div className="px-3 py-2 rounded-lg border border-stone-200 bg-stone-100 text-stone-700 flex items-center justify-between">
                      <span>
                        {currentFieldObj?.weather?.temperature}°C • {currentFieldObj?.weather?.humidity}% RH
                      </span>
                      <span className="text-[10px] text-emerald-800 font-semibold bg-emerald-100 px-1.5 py-0.5 rounded">
                        Sensors Connected
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-3">
                  <label className="block text-stone-600 font-medium text-xs mb-1">
                    Farmer's Symptom Notes / Observations (Optional)
                  </label>
                  <textarea
                    rows={2}
                    value={farmerNotes}
                    onChange={(e) => setFarmerNotes(e.target.value)}
                    placeholder="e.g., Spots observed after 2 days of rain; shedding of lower leaves noticed."
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-white text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Context Summary pill */}
              <div className="p-3 bg-emerald-50/70 border border-emerald-200/80 rounded-xl text-xs text-emerald-950 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0" />
                <span>
                  <strong>Field Memory Activated:</strong> Analysis will combine leaf imagery with {currentFieldObj?.name}
                  's 2-year disease history, local weather forecasts, and pest trap counts.
                </span>
              </div>
            </>
          )}

          {/* Analyzing Step */}
          {step === 'analyzing' && (
            <div className="py-12 text-center space-y-4">
              <div className="relative w-16 h-16 mx-auto">
                <div className="w-16 h-16 rounded-full border-4 border-emerald-200 border-t-emerald-700 animate-spin" />
                <Sparkles className="w-6 h-6 text-emerald-700 absolute inset-0 m-auto" />
              </div>
              <div>
                <h4 className="font-bold text-base text-stone-900">
                  Running Multimodal Agronomic Reasoning
                </h4>
                <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                  {analyzingProgress}
                </p>
              </div>
            </div>
          )}

          {/* Result Step */}
          {step === 'result' && analysisResult && (
            <div className="space-y-5">
              {/* Primary Suspected Diagnosis Card */}
              <div className="p-4 rounded-xl bg-emerald-900 text-white shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-800 text-emerald-200 text-[11px] font-semibold uppercase tracking-wider">
                      Possible Diagnosis
                    </span>
                    <span className="text-xs text-emerald-300">
                      Engine: {analysisResult.source}
                    </span>
                  </div>
                  <div className="px-2.5 py-0.5 rounded-full bg-emerald-800/80 border border-emerald-700 text-xs font-bold text-emerald-100">
                    Confidence: {analysisResult.confidence}% ({analysisResult.possibleIssues[0]?.likelihood || 'Likely'})
                  </div>
                </div>

                <h3 className="text-lg font-bold text-white tracking-tight">
                  {analysisResult.possibleIssues[0]?.name || 'Suspected Crop Condition'}
                </h3>
                {analysisResult.possibleIssues[0]?.pathogenOrPest && (
                  <p className="text-xs text-emerald-300 italic">
                    Pathogen/Vector: {analysisResult.possibleIssues[0].pathogenOrPest}
                  </p>
                )}

                <div className="mt-3 pt-3 border-t border-emerald-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="text-emerald-200">
                    <span className="font-semibold text-white">Recommended Next Step: </span>
                    {analysisResult.recommendedNextStep}
                  </div>
                </div>
              </div>

              {/* Explainable AI Panel */}
              <ExplainableAIPanel analysis={analysisResult} />

              {/* IPM Management Guidance */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-stone-900 uppercase tracking-wider">
                    Integrated Pest & Disease Management (IPM) Advisory
                  </h4>
                  <span className="text-[10px] text-stone-500 font-medium">
                    Prioritized Safe Interventions
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {analysisResult.managementActions.map((action, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-white rounded-lg border border-stone-200/80 shadow-2xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-900 text-[11px]">
                          {action.category}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-stone-100 text-stone-600 font-semibold">
                          Priority {action.priority}
                        </span>
                      </div>
                      <p className="text-stone-700 leading-relaxed">{action.action}</p>
                    </div>
                  ))}
                </div>

                {/* Safety / Anti-reckless disclaimer */}
                <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200/80 text-[11px] text-amber-900 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <span>
                    <strong>Cautionary Input Notice:</strong> No automated pesticide recipes are prescribed.
                    Always consult registered label directions and verify with your local Block Agricultural Extension
                    Officer before applying any chemical formulation.
                  </span>
                </div>
              </div>

              {/* Case Saved Message Banner */}
              {caseSavedMessage && (
                <div className="p-3 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-950 text-xs font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  <span>Case logged successfully! Assigned to extension review queue.</span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between">
          {step === 'input' && (
            <>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={runAnalysis}
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-sm flex items-center gap-2 transition-colors"
              >
                <Sparkles className="w-4 h-4" />
                <span>Run Crop Health Intelligence Scan</span>
              </button>
            </>
          )}

          {step === 'result' && (
            <>
              <button
                type="button"
                onClick={() => setStep('input')}
                className="px-3 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Re-scan Image</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-200 rounded-lg"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleSaveAsCase}
                  disabled={submittingCase || caseSavedMessage}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white text-xs font-bold rounded-xl shadow-sm flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>
                    {submittingCase
                      ? 'Logging Case...'
                      : caseSavedMessage
                      ? 'Saved!'
                      : 'Log Case & Request Validation'}
                  </span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
